<?php $__env->startSection('content'); ?>
<section class="about-generic-area">
				<div class="container border-top-generic">
					<h3 class="about-title mb-70">More about Cactus</h3>
					<div class="row">
						<div class="col-md-12">
							<div class="img-text">
								<img src="img/a.jpg" alt="" class="img-fluid float-left mr-20 mb-20">
								<p>Cactus spines are produced from specialized structures called areoles, a kind of highly reduced branch. Areoles are an identifying feature of cacti. As well as spines, areoles give rise to flowers, which are usually tubular and multipetaled. Many cacti have short growing seasons and long dormancies, and are able to react quickly to any rainfall, helped by an extensive but relatively shallow root system that quickly absorbs any water reaching the ground surface. Cactus stems are often ribbed or fluted, which allows them to expand and contract easily for quick water absorption after rain, followed by long drought periods. Like other succulent plants, most cacti employ a special mechanism called "crassulacean acid metabolism" (CAM) as part of photosynthesis. Transpiration, during which carbon dioxide enters the plant and water escapes, does not take place during the day at the same time as photosynthesis, but instead occurs at night. The plant stores the carbon dioxide it takes in as malic acid, retaining it until daylight returns, and only then using it in photosynthesis. Because transpiration takes place during the cooler, more humid night hours, water loss is significantly reduced. </p>
							</div>
						</div>
						<div class="col-lg-12">
							<p>Many smaller cacti have globe-shaped stems, combining the highest possible volume for water storage, with the lowest possible surface area for water loss from transpiration. The tallest[Note 2] free-standing cactus is Pachycereus pringlei, with a maximum recorded height of 19.2 m (63 ft),[6] and the smallest is Blossfeldia liliputiana, only about 1 cm (0.4 in) in diameter at maturity.[7] A fully grown saguaro (Carnegiea gigantea) is said to be able to absorb as much as 200 U.S. gallons (760 l; 170 imp gal) of water during a rainstorm.[8] A few species differ significantly in appearance from most of the family. At least superficially, plants of the genus Pereskia resemble other trees and shrubs growing around them. They have persistent leaves, and when older, bark-covered stems. Their areoles identify them as cacti, and in spite of their appearance, they, too, have many adaptations for water conservation. Pereskia is considered close to the ancestral species from which all cacti evolved. In tropical regions, other cacti grow as forest climbers and epiphytes (plants that grow on trees). Their stems are typically flattened, almost leaf-like in appearance, with fewer or even no spines, such as the well-known Christmas cactus or Thanksgiving cactus (in the genus Schlumbergera). </p>
						</div>
						<div class="col-lg-12">
							<p>The 1,500 to 1,800 species of cacti mostly fall into one of two groups of "core cacti": opuntias (subfamily Opuntioideae) and "cactoids" (subfamily Cactoideae). Most members of these two groups are easily recognizable as cacti. They have fleshy succulent stems that are major organs of photosynthesis. They have absent, small, or transient leaves. They have flowers with ovaries that lie below the sepals and petals, often deeply sunken into a fleshy receptacle (the part of the stem from which the flower parts grow). All cacti have areoles—highly specialized short shoots with extremely short internodes that produce spines, normal shoots, and flowers.[9]

The remaining cacti fall into only two genera, Pereskia and Maihuenia, and are rather different,[9] which means any description of cacti as a whole must frequently make exceptions for them. Pereskia species superficially resemble other tropical forest trees. When mature, they have woody stems that may be covered with bark and long-lasting leaves that provide the main means of photosynthesis. Their flowers may have superior ovaries (i.e., above the points of attachment of the sepals and petals), and areoles that produce further leaves. The two species of Maihuenia have small, globe-shaped bodies with prominent leaves at the top.[9] </p>
						</div>
						<div class="col-md-12">
							<div class="img-text">
								<img src="img/a2.jpg" alt="" class="img-fluid float-left mr-20 mb-20">
								<p>They can be tree-like (arborescent), meaning they typically have a single more-or-less woody trunk topped by several to many branches. In the genus Pereskia, the branches are covered with leaves, so the species of this genus may not be recognized as cacti. In most other cacti, the branches are more typically cactus-like, bare of leaves and bark, and covered with spines, as in Pachycereus pringlei or the larger opuntias. Some cacti may become tree-sized but without branches, such as larger specimens of Echinocactus platyacanthus. Cacti may also be described as shrubby, with several stems coming from the ground or from branches very low down, such as in Stenocereus thurberi.[10]</p>
							</div>
						</div>
					</div>
				</div>
	
			</section>
<footer class="entry-footer flex flex-column flex-lg-row justify-content-between align-content-start align-lg-items-center">
                        <ul class="post-share flex align-items-center order-3 order-lg-1">
                            <label>Share</label>
                            <li><a href="#"><i class="fa fa-pinterest"></i></a></li>
                            <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                            <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                        </ul>
						</footer>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>