<!DOCTYPE html>
<html lang="en">
<head>
<title>ASHNET</title>
<meta charset="utf-8">
	 <link rel="icon" type="image/png" href="img/favicon.ico">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="Demo project">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="<?php echo e(URL::asset('styles/bootstrap4/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" >
<link href="<?php echo e(URL::asset('plugins/font-awesome-4.7.0/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css" >
<link href="<?php echo e(URL::asset('plugins/OwlCarousel2-2.2.1/owl.carousel.css')); ?>" rel="stylesheet" type="text/css" >
<link href="<?php echo e(URL::asset('plugins/OwlCarousel2-2.2.1/owl.theme.default.css')); ?>" rel="stylesheet" type="text/css" >
<link href="<?php echo e(URL::asset('plugins/OwlCarousel2-2.2.1/animate.css')); ?>" rel="stylesheet" type="text/css" >
<link href="<?php echo e(URL::asset('plugins/jquery.mb.YTPlayer-3.1.12/jquery.mb.YTPlayer.css')); ?>" rel="stylesheet" type="text/css" >
<link href="<?php echo e(URL::asset('styles/main_styles.css')); ?>" rel="stylesheet" type="text/css" >
<link href="<?php echo e(URL::asset('styles/responsive.css')); ?>" rel="stylesheet" type="text/css" >
	<link href="<?php echo e(URL::asset('video/video.css')); ?>" rel="stylesheet" type="text/css" >
</head>
<body>
	<div class="super_container">
	<?php echo $__env->make('inc.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
           <?php echo $__env->yieldContent('content'); ?>
     
          
   
	
	
	<footer class="footer">
                <div class="container">
			
				
					<div class="footer_content">
						<div class="footer_logo"><a href="<?php echo e(url('/')); ?>"><img src="img/logo2.png" alt=""></a>
						
						
					
				</div>
				
			
		</div>
	</footer>
	</div>
	
	
	
     <script type="text/javascript" src="<?php echo e(asset('js/jquery-3.2.1.min.js')); ?>"></script>
 <script type="text/javascript" src="<?php echo e(asset('styles/bootstrap4/popper.js')); ?>"></script>
 <script type="text/javascript" src="<?php echo e(asset('styles/bootstrap4/bootstrap.min.js')); ?>"></script>
 <script type="text/javascript" src="<?php echo e(asset('plugins/OwlCarousel2-2.2.1/owl.carousel.js')); ?>"></script>
 <script type="text/javascript" src="<?php echo e(asset('plugins/jquery.mb.YTPlayer-3.1.12/jquery.mb.YTPlayer.js')); ?>"></script>
 <script type="text/javascript" src="<?php echo e(asset('plugins/easing/easing.js')); ?>"></script>
 <script type="text/javascript" src="<?php echo e(asset('plugins/masonry/masonry.js')); ?>"></script>
 <script type="text/javascript" src="<?php echo e(asset('plugins/masonry/images_loaded.js')); ?>"></script>
 <script type="text/javascript" src="<?php echo e(asset('js/custom.js')); ?>"></script>
</body>
</html>


