<?php $__env->startSection('header'); ?>
                         <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						 <?php echo $__env->make('pages.header', ['post' => $post], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>





<div class="home">
		
		<!-- Home Slider -->

		<div class="home_slider_container">
			<div class="owl-carousel owl-theme home_slider">
				
				<!-- Slider Item -->
				<div class="owl-item">
					<div class="parallax-background" id="fullScreenDiv">
					<img src="images/home_slider.jpg" id="videosubstitute" alt="Full screen background video">
      
        <div id="videoDiv">           
            <video preload="preload" id="video" autoplay="autoplay" loop="loop">
         
            <source src="video/sky1.mp4" type="video/mp4"></source>
            </video> 
        </div>
        
    </div> 
				
				
				<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						
				
					<div class="home_slider_content_container">
						<div class="container">
							<div class="row">
								<div class="col">
									<div class="home_slider_content">
										<div class="home_slider_item_category trans_200"><a href="category.html" class="trans_200">Space Exploration</a></div>
										<div class="home_slider_item_title">
											<a href="#">NASA would really prefer that Mars astronauts produce their materials on Mars.</a>
										</div>
										<div class="home_slider_item_link">
											<a href="" class="trans_200">Continue Reading
												<svg version="1.1" id="link_arrow_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
													 width="19px" height="13px" viewBox="0 0 19 13" enable-background="new 0 0 19 13" xml:space="preserve">
													<polygon fill="#FFFFFF" points="12.475,0 11.061,0 17.081,6.021 0,6.021 0,7.021 17.038,7.021 11.06,13 12.474,13 18.974,6.5 "/>
												</svg>
											</a>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

					<!-- Similar Posts -->
					
				</div>

				<!-- Slider Item -->
			

			</div>
	<div class="home_slider_next_container">
							<div class="home_slider_next" style="background-image:url(images/home_slider_next.jpg)">
								<div class="home_slider_next_background trans_400"></div>
								<div class="home_slider_next_content trans_400">
									<div class="home_slider_next_title">next</div>
									<div class="home_slider_next_link">How Did van Gogh’s Turbulent Mind Depict One of the Most Complex Concepts in Physics?</div>
								</div>
							</div>
						</div>

			

		</div>
	</div>











<div class="page_content">
		<div class="container">
			<div class="row row-lg-eq-height">

				<!-- Main Content -->

				<div class="col-lg-9">
					<div class="main_content">

						<!-- Blog Section - Don't Miss -->

						<div class="blog_section">
							<div class="section_panel d-flex flex-row align-items-center justify-content-start">
								<div class="section_title">Don't Miss</div>
								<div class="section_tags ml-auto">
									<ul>
										
										<?php echo e(menu('main')); ?>

										
										<!--<li class="active"><a href="category.html">all</a></li>
										<li><a href="category.html">Space Exploration</a></li>
										<li><a href="category.html">technology</a></li>
										<li><a href="category.html">health & fitness</a></li>
										<li><a href="category.html">Future</a></li> -->
									</ul>
								</div>
								<div class="section_panel_more">
									<ul>
										<li>more
											<ul>
												<li><a href="category.html">new look 2018</a></li>
												<li><a href="category.html">street fashion</a></li>
												<li><a href="category.html">business</a></li>
												<li><a href="category.html">recipes</a></li>
												<li><a href="category.html">sport</a></li>
												<li><a href="category.html">celebrities</a></li>
											</ul>
										</li>
									</ul>
								</div>
							</div>
							
							
							<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php echo $__env->make('pages.post', ['post' => $post], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							
							
						</div>

						<!-- Blog Section - What's Trending -->
						

						

						<!-- Blog Section - Videos -->
                              
						

						<!-- Blog Section - Latest -->

						

					</div>
					
					<?php echo e($posts->links()); ?>

					
				</div>

				<!-- Sidebar -->
				

				

			</div>
		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.fat', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>