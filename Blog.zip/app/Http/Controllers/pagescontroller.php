<?php

namespace App\Http\Controllers;
use App\Post;
use App\Photo;
use Illuminate\Http\Request;

class pagescontroller extends Controller
{
    //
	public function getblog(){
		
		$posts = Photo::paginate(4); 
		return view('blog', ['posts' => $posts]);
	}
	
	public function getHome(){
		return view('home');
	}
	public function getcactus(){
		return view('cactus');
	}
	
	
	
	public function getSpace(){
		$posts = Photo::paginate(4); 
		return view('category', ['posts' => $posts]);
	}
	public function gettech(){
		$posts = Photo::paginate(4); 
		return view('category', ['posts' => $posts]);
	}
	public function gethealth(){
		$posts = Photo::paginate(4); 
		return view('category', ['posts' => $posts]);
	}
	public function getfuture(){
		$posts = Photo::paginate(4); 
		return view('category', ['posts' => $posts]);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	public function show($slug)
	
	{
		$post = Photo::findBySlug($slug);
		return view('post.show',['post'=> $post]);
	}
	
	
}
