<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class Photo extends Model
{
   public function author()
	{
		return $this->belongsTo(user::class,'author_id');
	}
	
	
	public static function findbyslug($slug)
	{
		return static::where('slug',$slug)->first();
	} 
}
