<div class="section_content">
								<div class="grid clearfix">

									<!-- Largest Card With Image -->
									<div class="card card_largest_with_image grid-item">
										<img class="card-img-top" src="images/post_1.jpg" alt="https://unsplash.com/@cjtagupa">
										<div class="card-body">
											<div class="card-title"><a href="post.html"> {{$post->title}}</a></div>
											<p class="card-text">{{$post->excerpt}}</p>
											<small class="post_meta"><a href="#">{{$post->author_id}}</a><span>{{$post->created_at}}</span></small>
										</div>
									</div>
	</div>
</div>
