<div class="section_content">
								<div class="grid clearfix">

									<!-- Largest Card With Image -->
									<div class="card card_largest_with_image grid-item">
										<img class="card-img-top" src="{{asset('/storage/'.$post->image)}}" alt="{{$post->image}}">
										<div class="card-body">
											<div class="card-title"><a href="/post/{{$post->slug}}">{{$post->title}}</a></div>
											<p class="card-text">{{$post->excerpt}}</p>
											<small class="post_meta"><a href="#">{{$post->author}}</a><span>{{$post->created_at}}</span></small>
										</div>
									</div>

									<!-- Small Card Without Image 
									<div class="card card_default card_small_no_image grid-item">
										<div class="card-body">
											<div class="card-title card-title-small"><a href="post.html">{{$post->title}}</a></div>
											<small class="post_meta"><a href="#">Katy Liu</a><span>Sep 29, 2017 at 9:48 am</span></small>
										</div>
									</div>

									<!-- Small Card With Background 
									<div class="card card_default card_small_with_background grid-item">
										<div class="card_background" style="background-image:url(images/post_4.jpg)"></div>
										<div class="card-body">
											<div class="card-title card-title-small"><a href="post.html">{{$post->title}}</a></div>
											<small class="post_meta"><a href="#">Katy Liu</a><span>Sep 29, 2017 at 9:48 am</span></small>
										</div>
									</div>

									<!-- Small Card With Image 
									<div class="card card_small_with_image grid-item">
										<img class="card-img-top" src="images/post_2.jpg" alt="https://unsplash.com/@jakobowens1">
										<div class="card-body">
											<div class="card-title card-title-small"><a href="post.html">{{$post->title}}</a></div>
											<small class="post_meta"><a href="#">Katy Liu</a><span>Sep 29, 2017 at 9:48 am</span></small>
										</div>
									</div>

									<!-- Small Card With Image 
									<div class="card card_small_with_image grid-item">
										<img class="card-img-top" src="images/post_3.jpg" alt="https://unsplash.com/@jannerboy62">
										<div class="card-body">
											<div class="card-title card-title-small"><a href="post.html">How Did van Gogh’s Turbulent Mind Depict One of the Most Complex Concepts in Physics?</a></div>
											<small class="post_meta"><a href="#">Katy Liu</a><span>Sep 29, 2017 at 9:48 am</span></small>
										</div>
									</div>

									<!-- Default Card No Image 

									<div class="card card_default card_default_no_image grid-item">
										<div class="card-body">
											<div class="card-title card-title-small"><a href="post.html">{{$post->title}}</a></div>
										</div>
									</div>

									<!-- Default Card No Image 

									<div class="card card_default card_default_no_image grid-item">
										<div class="card-body">
											<div class="card-title card-title-small"><a href="post.html">How Did van Gogh’s Turbulent Mind Depict One of the Most</a></div>
										</div>
									</div>

									<!-- Default Card No Image -->

									<div class="card card_default card_default_no_image grid-item">
										<div class="card-body">
											<div class="card-title card-title-small"><a href="post.html"></a></div>
										</div>
									</div> 

								</div>
							</div>