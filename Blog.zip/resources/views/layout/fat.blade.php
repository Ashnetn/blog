<!DOCTYPE html>
<html lang="en">
<head>
<title>{{setting('site.title')}}</title>
<meta charset="utf-8">
	 <link rel="icon" type="image/png" href="img/favicon.ico">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="Demo project">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="{{ URL::asset('styles/bootstrap4/bootstrap.min.css') }}" rel="stylesheet" type="text/css" >
<link href="{{ URL::asset('plugins/font-awesome-4.7.0/css/font-awesome.min.css') }}" rel="stylesheet" type="text/css" >
<link href="{{ URL::asset('plugins/OwlCarousel2-2.2.1/owl.carousel.css') }}" rel="stylesheet" type="text/css" >
<link href="{{ URL::asset('plugins/OwlCarousel2-2.2.1/owl.theme.default.css') }}" rel="stylesheet" type="text/css" >
<link href="{{ URL::asset('plugins/OwlCarousel2-2.2.1/animate.css') }}" rel="stylesheet" type="text/css" >
<link href="{{ URL::asset('plugins/jquery.mb.YTPlayer-3.1.12/jquery.mb.YTPlayer.css') }}" rel="stylesheet" type="text/css" >
<link href="{{ URL::asset('styles/main_styles.css') }}" rel="stylesheet" type="text/css" >
<link href="{{ URL::asset('styles/responsive.css') }}" rel="stylesheet" type="text/css" >
	<link href="{{ URL::asset('video/video.css') }}" rel="stylesheet" type="text/css" >
</head>
<body>
	<div class="super_container">
	@include('inc.navbar') 
		 @yield('header')
           @yield('content')
		  
     
          
   
	
	
	<footer class="footer">
                <div class="container">
			
				
					<div class="footer_content">
						<div class="footer_logo"><a href="{{url('/')}}"><img src="{{asset('/storage/'.setting('site.footer_logo'))}}" alt=""></a>
						
						
					
				</div>
				
					</div>
		</div>
	</footer>
	</div>
	
	
	
     <script type="text/javascript" src="{{ asset('js/jquery-3.2.1.min.js') }}"></script>
 <script type="text/javascript" src="{{ asset('styles/bootstrap4/popper.js') }}"></script>
 <script type="text/javascript" src="{{ asset('styles/bootstrap4/bootstrap.min.js') }}"></script>
 <script type="text/javascript" src="{{ asset('plugins/OwlCarousel2-2.2.1/owl.carousel.js') }}"></script>
 <script type="text/javascript" src="{{ asset('plugins/jquery.mb.YTPlayer-3.1.12/jquery.mb.YTPlayer.js') }}"></script>
 <script type="text/javascript" src="{{ asset('plugins/easing/easing.js') }}"></script>
 <script type="text/javascript" src="{{ asset('plugins/masonry/masonry.js') }}"></script>
 <script type="text/javascript" src="{{ asset('plugins/masonry/images_loaded.js') }}"></script>
 <script type="text/javascript" src="{{ asset('js/custom.js') }}"></script>
</body>
</html>


