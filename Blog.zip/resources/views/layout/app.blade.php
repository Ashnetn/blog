<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <link rel="icon" type="image/png" href="img/favicon.ico">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
        <title>ASHNET :: Freestyle Blog </title>
        <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
        <meta name="viewport" content="width=device-width" />

        <link href="{{ asset('css/bootstrap.css') }}" rel="stylesheet" type="text/css" >
        <link href="{{ asset('css/landing-page.css') }}" rel="stylesheet" type="text/css" >

        <!--     Fonts and icons     -->
        
        <link href="{{ URL::asset('css/linearicons.css') }}" rel="stylesheet" type="text/css" >
		<link href="{{ URL::asset('css/owl.carousel.css') }}" rel="stylesheet" type="text/css" >
		<link href="{{ URL::asset('css/font-awesome.min.css') }}" rel="stylesheet" type="text/css" >
		<link href="{{ URL::asset('css/nice-select.css') }}" rel="stylesheet" type="text/css" >
		<link href="{{ URL::asset('css/magnific-popup.css') }}" rel="stylesheet" type="text/css" >
		<link href="{{ URL::asset('css/main.css') }}" rel="stylesheet" type="text/css" >
		
        
       
        
        <link href="{{ URL::asset('http://fonts.googleapis.com/css?family=Open+Sans:300italic,400,300') }}" rel="stylesheet" type="text/css" >
        
        
      
       
        
       
        
       <!-- <link rel="stylesheet" href="/css/app.css"> -->

    </head>
    <body class="landing-page landing-page1">
		
		<div class="oz-body-wrap">
		<!-- Start Header Area -->
			<header class="default-header">
			<div class="container-fluid">
				<div class="header-wrap">
					<div class="header-top d-flex justify-content-between align-items-center">
						<div class="logo">
							<a href="{{url('/')}}"><img src="img/logo.png" alt=""></a>
						</div>
						<div class="main-menubar d-flex align-items-center">
							<nav class="hide">
								<a href="{{url('/blog')}}">Home</a>
								<a href="http://ashnet.ml">About Me</a>
								
							</nav>
							<div class="menu-bar"><span class="lnr lnr-menu"></span></div>
						</div>
					</div>
				</div>
			</div>
		</header>
		
     
       
        @yield('content')
			
		</div>
      <footer class="footer">
                <div class="container">
                    <nav class="pull-left">
                        <ul>
                            <li>
                                
                                     <a class="nav-link"rel="tooltip" title="Home" data-placement="bottom" href="{{url('/')}}" >
                                <i class="fa fa-spinner fa-spin "></i>
                                </a>
                            </li>
                            <li>
                                 <a class="nav-link" rel="tooltip" title="Work" data-placement="bottom" href="http://www.pentagononline.net"target="_blank">
                                <i class="fa fa-briefcase "></i>
                                </a>
                            </li>
                            <li>
                                <a class="nav-link"rel="tooltip" title="Blog" data-placement="bottom" href="{{url('/frames')}}" >
                                <i class="fa fa-camera "></i>
                                </a>
                            </li>
                           
                        </ul>
                    </nav>
                    <div class="social-area pull-right">
                        <a href="http://www.fb.com/ashiquens" class="btn btn-social btn-facebook btn-simple">
                        <i class="fa fa-facebook-square"></i>
                        </a>
                        <a class="btn btn-social btn-twitter btn-simple">
                        <i class="fa fa-twitter"></i>
                        </a>
                        <a href="http://www.instagram.com/____ash__________" class="btn btn-social btn-instagram btn-simple">
                        <i class="fa fa-instagram"></i>
                        </a>
                    </div>
                    <div class="copyright">
                        &copy; 2018 <a href="#"> 
                        ASHNET
                    </a>
                    </div>
                </div>
            </footer>
    </body>
    
    <script type="text/javascript" src="{{ asset('js/jquery-2.2.4.min.js') }}"></script>
    <script type="text/javascript" src="{{ asset('js/vendor/bootstrap.min.js') }}"></script>
    <script type="text/javascript" src="{{ asset('js/jquery.ajaxchimp.min.js') }}"></script>
    <script type="text/javascript" src="{{ asset('js/owl.carousel.min.js') }}"></script>
	 <script type="text/javascript" src="{{ asset('js/jquery.nice-select.min.js') }}"></script>
	 <script type="text/javascript" src="{{ asset('js/jquery.magnific-popup.min.js') }}"></script>
	 <script type="text/javascript" src="{{ asset('js/jquery.counterup.min.js') }}"></script>
	 <script type="text/javascript" src="{{ asset('js/waypoints.min.js') }}"></script>
    	 <script type="text/javascript" src="{{ asset('js/main.js') }}"></script>
    
    
    
    
</html>
